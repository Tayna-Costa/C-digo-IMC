package com.example.codigo_imc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
